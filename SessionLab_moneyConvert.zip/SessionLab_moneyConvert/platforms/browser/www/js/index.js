/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
var app = {
    // Application Constructor
    initialize: function() {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function() {
        app.receivedEvent('deviceready');
    },
    // Update DOM on a Received Event
    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');

        console.log('Received Event: ' + id);
    }
};

function convert1() {
		
		var amount1 = document.getElementById('amount1').value;

		
		
	    var http = new XMLHttpRequest();
		
		//API to convert 
		const url = 'http://www.apilayer.net/api/live?access_key=b462bfd8de37e8ff52612a982c2159f2';
		
		http.open("GET", url);
		// Sending the request
		http.send();
		
		http.onreadystatechange = (e) => {
        
			// First, I'm extracting the reponse from the 
			// http object in text format
			var response = http.responseText;

			// As we know that answer is a JSON object,
			// we can parse it and handle it as such
			var responseJSON = JSON.parse(response); 
		
			// Printing the result JSON to the console
			console.log(responseJSON);

			// Extracting the individual values, just as we
			// do with any JSON object. Just as we did 
			// with the position.
			// REMEMBER: In this case, we have an array inside 
			// the JSON object.
			var currency = responseJSON.quotes.USDBRL;
			
			console.log(currency);


			// Formattng data to put it on the front end
			var c = "Currency: " + currency;
			var converted = "Total: " +currency * amount1;

			// Placing formatted data on the front ed
			document.getElementById('currency').innerHTML = c;
			document.getElementById('total').innerHTML = converted;
    }
}	

// function to convert Brazilian Real in American Dollar	
function convert2() {
		

	    var amount2 = document.getElementById('amount2').value;
		
		
	    var http = new XMLHttpRequest();
		
		const url = 'http://www.apilayer.net/api/live?access_key=b462bfd8de37e8ff52612a982c2159f2';
		
		http.open("GET", url);
		// Sending the request
		http.send();
		
		http.onreadystatechange = (e) => {
        
			// extracting the reponse from the 
			// http object in text format
			var response = http.responseText;

			var responseJSON = JSON.parse(response); 
		
			// Printing the result JSON to the console
			console.log(responseJSON);

			// Extracting the individual values, just as we
			// do with any JSON object. Just as we did 
			// with the position.

			var currency = responseJSON.quotes.USDBRL;
			
			//testing if my responseJSON is getting the value
			console.log(currency);


			// Formattng data to put it on the front end
			var c = "Currency: " + currency;
			var converted = "Total: " + amount2 / currency;

			// Placing formatted data on the front ed
			document.getElementById('currency2').innerHTML = c;
			document.getElementById('total2').innerHTML = converted;
    }
}	
		
	
	
	